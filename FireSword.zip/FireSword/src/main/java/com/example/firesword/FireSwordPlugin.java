package com.example.firesword;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class FireSwordPlugin extends JavaPlugin implements Listener {

    // ---- Tweak these ----
    private static final int BURN_TICKS = 100;                // 5 seconds of burning on hit
    private static final long FIREBALL_COOLDOWN_MS = 3000;    // right-click air
    private static final int FIREBALL_COUNT = 3;              // fireballs per right-click
    private static final double FIREBALL_SPREAD_DEGREES = 8;  // angle between fireballs
    private static final double FIREBALL_DAMAGE = 10.0;       // 5 hearts per fireball
    private static final double FIREBALL_BLAST_RADIUS = 3.0;  // blocks
    private static final int SHIELD_TICKS = 200;              // shield lasts 10 seconds
    private static final long SHIELD_COOLDOWN_MS = 20000;     // 20 seconds between shields
    private static final double SHIELD_RADIUS = 3.0;          // blocks
    private static final double SHIELD_DAMAGE = 4.0;          // 2 hearts per hit to enemies in range
    private static final int SHIELD_INTERVAL_TICKS = 10;      // hits twice a second (4 hearts/sec)
    private static final int CUSTOM_MODEL_ID = 1;             // must match the resource pack

    private NamespacedKey swordKey;
    private NamespacedKey fireballKey;
    private final Map<UUID, Long> fireballCooldowns = new HashMap<>();
    private final Map<UUID, Long> shieldCooldowns = new HashMap<>();
    private final Map<UUID, BukkitRunnable> shields = new HashMap<>();

    @Override
    public void onEnable() {
        swordKey = new NamespacedKey(this, "fire_sword");
        fireballKey = new NamespacedKey(this, "fire_sword_fireball");
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("FireSword enabled.");
        if (getConfig().getBoolean("resource-pack.enabled", true) && !packConfigured()) {
            getLogger().warning("Resource pack is not set up yet: edit plugins/FireSword/config.yml and set resource-pack.url.");
        }
    }

    @Override
    public void onDisable() {
        for (BukkitRunnable task : shields.values()) {
            task.cancel();
        }
        shields.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        if (args.length > 0) {
            target = getServer().getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(Component.text("Console must specify a player.", NamedTextColor.RED));
            return true;
        }

        target.getInventory().addItem(createFireSword());
        target.sendMessage(Component.text("You received the Fire Sword!", NamedTextColor.GOLD));
        return true;
    }

    // ---------------------------------------------------------------- item

    private ItemStack createFireSword() {
        ItemStack item = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("Fire Sword", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                line("Ignites enemies on hit", NamedTextColor.RED),
                line("Right-click air: 3 explosive fireballs", NamedTextColor.YELLOW),
                line("Right-click ground: set it ablaze", NamedTextColor.YELLOW),
                line("Sneak + right-click: Fire Shield", NamedTextColor.GOLD)
        ));
        meta.setEnchantmentGlintOverride(true);
        meta.setUnbreakable(true);
        meta.setCustomModelData(CUSTOM_MODEL_ID);   // resource pack swaps in the fire sword model
        meta.getPersistentDataContainer().set(swordKey, PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    private Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private boolean isFireSword(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(swordKey, PersistentDataType.BYTE);
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        if (!player.hasPermission("firesword.use")) return;
        if (!isFireSword(player.getInventory().getItemInMainHand())) return;

        victim.setFireTicks(BURN_TICKS);
        victim.getWorld().spawnParticle(Particle.FLAME, victim.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.02);
        victim.getWorld().playSound(victim.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1f, 1f);
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("firesword.use")) return;
        if (!isFireSword(player.getInventory().getItemInMainHand())) return;

        event.setCancelled(true);

        if (player.isSneaking()) {
            toggleShield(player);
        } else if (action == Action.RIGHT_CLICK_BLOCK) {
            igniteGround(player, event.getClickedBlock(), event.getBlockFace());
        } else {
            shootFireballs(player);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        stopShield(event.getPlayer());
    }

    // ---------------------------------------------------------------- resource pack

    private boolean packConfigured() {
        String url = getConfig().getString("resource-pack.url", "");
        return !url.isBlank() && !url.contains("YOUR-USERNAME") && !url.contains("YOUR-REPO-NAME");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!getConfig().getBoolean("resource-pack.enabled", true)) return;
        if (!packConfigured()) return;

        String url = getConfig().getString("resource-pack.url", "");
        boolean force = getConfig().getBoolean("resource-pack.force", false);
        Component prompt = Component.text(
                getConfig().getString("resource-pack.prompt", "Fire Sword resource pack"), NamedTextColor.GOLD);

        byte[] hash = null;
        String sha1 = getConfig().getString("resource-pack.sha1", "").trim();
        if (!sha1.isEmpty()) {
            try {
                hash = HexFormat.of().parseHex(sha1);
                if (hash.length != 20) throw new IllegalArgumentException("wrong length");
            } catch (IllegalArgumentException e) {
                getLogger().warning("resource-pack.sha1 must be 40 hex characters; sending the pack without it.");
                hash = null;
            }
        }

        final byte[] finalHash = hash;
        Player player = event.getPlayer();
        // Wait one second so the player is fully loaded in before the download prompt appears
        getServer().getScheduler().runTaskLater(this, () -> {
            if (player.isOnline()) {
                player.setResourcePack(url, finalHash, prompt, force);
            }
        }, 20L);
    }

    // ---------------------------------------------------------------- fireballs

    private void shootFireballs(Player player) {
        long now = System.currentTimeMillis();
        long readyAt = fireballCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < readyAt) {
            player.sendActionBar(Component.text("Fireball cooldown: " + secs(readyAt - now), NamedTextColor.RED));
            return;
        }
        fireballCooldowns.put(player.getUniqueId(), now + FIREBALL_COOLDOWN_MS);

        Vector direction = player.getLocation().getDirection();
        for (int i = 0; i < FIREBALL_COUNT; i++) {
            // Fan the fireballs out evenly around where you're looking
            double offset = (i - (FIREBALL_COUNT - 1) / 2.0) * FIREBALL_SPREAD_DEGREES;
            Vector aim = direction.clone().rotateAroundY(Math.toRadians(offset));

            Fireball fireball = player.launchProjectile(Fireball.class, aim.clone().multiply(1.2));
            fireball.setDirection(aim);
            fireball.setYield(0f);              // no vanilla explosion; we make our own on impact
            fireball.setIsIncendiary(false);
            fireball.getPersistentDataContainer().set(fireballKey, PersistentDataType.BYTE, (byte) 1);
        }
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
    }

    @EventHandler
    public void onFireballHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Fireball fireball)) return;
        if (!fireball.getPersistentDataContainer().has(fireballKey, PersistentDataType.BYTE)) return;

        // Skip the vanilla impact so the damage is exactly what we set below
        event.setCancelled(true);

        Location loc = fireball.getLocation();
        World world = loc.getWorld();
        Player shooter = fireball.getShooter() instanceof Player p ? p : null;
        fireball.remove();

        world.spawnParticle(Particle.EXPLOSION, loc, 1);
        world.spawnParticle(Particle.FLAME, loc, 40, 1.0, 1.0, 1.0, 0.05);
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);

        for (Entity e : world.getNearbyEntities(loc, FIREBALL_BLAST_RADIUS, FIREBALL_BLAST_RADIUS, FIREBALL_BLAST_RADIUS)) {
            if (e instanceof ArmorStand) continue;
            if (!(e instanceof LivingEntity target)) continue;
            if (shooter != null && e.getUniqueId().equals(shooter.getUniqueId())) continue;
            if (target.getLocation().distance(loc) > FIREBALL_BLAST_RADIUS) continue;

            target.setNoDamageTicks(0);         // so every fireball in the volley lands in full
            target.setFireTicks(BURN_TICKS);
            if (shooter != null) {
                target.damage(FIREBALL_DAMAGE, shooter);
            } else {
                target.damage(FIREBALL_DAMAGE);
            }
        }
    }

    // ---------------------------------------------------------------- ground fire

    private void igniteGround(Player player, Block clicked, BlockFace face) {
        if (clicked == null) return;

        Block spot = clicked.getRelative(face);
        tryIgnite(player, spot);

        // Clicking the top of a block lights a small plus-shaped patch
        if (face == BlockFace.UP) {
            tryIgnite(player, spot.getRelative(BlockFace.NORTH));
            tryIgnite(player, spot.getRelative(BlockFace.SOUTH));
            tryIgnite(player, spot.getRelative(BlockFace.EAST));
            tryIgnite(player, spot.getRelative(BlockFace.WEST));
        }
        player.getWorld().playSound(spot.getLocation(), Sound.ITEM_FLINTANDSTEEL_USE, 1f, 1f);
    }

    private void tryIgnite(Player player, Block block) {
        if (!block.getType().isAir()) return;
        if (!block.getRelative(BlockFace.DOWN).getType().isSolid()) return;

        // Fire the vanilla event first so protection plugins can say no
        BlockIgniteEvent ignite = new BlockIgniteEvent(block, BlockIgniteEvent.IgniteCause.FLINT_AND_STEEL, player);
        getServer().getPluginManager().callEvent(ignite);
        if (ignite.isCancelled()) return;

        block.setType(Material.FIRE);
        block.getWorld().spawnParticle(Particle.FLAME, block.getLocation().add(0.5, 0.3, 0.5), 8, 0.2, 0.1, 0.2, 0.01);
    }

    // ---------------------------------------------------------------- fire shield

    private void toggleShield(Player player) {
        if (shields.containsKey(player.getUniqueId())) {
            stopShield(player);   // sneak + right-click again ends it early
            return;
        }

        long now = System.currentTimeMillis();
        long readyAt = shieldCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < readyAt) {
            player.sendActionBar(Component.text("Fire Shield cooldown: " + secs(readyAt - now), NamedTextColor.RED));
            return;
        }
        shieldCooldowns.put(player.getUniqueId(), now + SHIELD_COOLDOWN_MS);
        startShield(player);
    }

    private void startShield(Player player) {
        // Fire immunity so your own shield (and lava, fire, etc.) can't hurt you while it's up
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, SHIELD_TICKS + 10, 0, false, false));
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1f, 0.6f);
        player.sendActionBar(Component.text("Fire Shield active!", NamedTextColor.GOLD));

        BukkitRunnable task = new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || ticks >= SHIELD_TICKS) {
                    stopShield(player);
                    return;
                }

                Location center = player.getLocation();
                World world = player.getWorld();

                // Ring of flame on the ground around you
                for (int i = 0; i < 16; i++) {
                    double a = angle + i * (Math.PI * 2 / 16);
                    world.spawnParticle(Particle.FLAME,
                            center.getX() + Math.cos(a) * SHIELD_RADIUS,
                            center.getY() + 0.1,
                            center.getZ() + Math.sin(a) * SHIELD_RADIUS,
                            1, 0, 0, 0, 0);
                }

                // Three tall flames orbiting you
                for (int i = 0; i < 3; i++) {
                    double a = -angle * 1.5 + i * (Math.PI * 2 / 3);
                    double height = 0.5 + 0.5 * (1 + Math.sin(angle * 2 + i));
                    world.spawnParticle(Particle.FLAME,
                            center.getX() + Math.cos(a) * (SHIELD_RADIUS - 0.5),
                            center.getY() + height,
                            center.getZ() + Math.sin(a) * (SHIELD_RADIUS - 0.5),
                            3, 0.1, 0.1, 0.1, 0.01);
                }
                angle += 0.3;

                // Burn and damage everything inside the ring, twice a second
                if (ticks % SHIELD_INTERVAL_TICKS == 0) {
                    for (Entity e : player.getNearbyEntities(SHIELD_RADIUS, SHIELD_RADIUS, SHIELD_RADIUS)) {
                        if (e instanceof ArmorStand) continue;
                        if (!(e instanceof LivingEntity target)) continue;
                        if (target.getLocation().distance(center) > SHIELD_RADIUS) continue;
                        target.setFireTicks(BURN_TICKS);
                        target.setNoDamageTicks(0);
                        target.damage(SHIELD_DAMAGE, player);
                    }
                }
                ticks++;
            }
        };
        task.runTaskTimer(this, 0L, 1L);
        shields.put(player.getUniqueId(), task);
    }

    private void stopShield(Player player) {
        BukkitRunnable task = shields.remove(player.getUniqueId());
        if (task == null) return;
        task.cancel();
        player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        if (player.isOnline()) {
            player.sendActionBar(Component.text("Fire Shield ended", NamedTextColor.GRAY));
        }
    }

    private static String secs(long ms) {
        return String.format("%.1fs", ms / 1000.0);
    }
}
