package com.example.firesword;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.damage.DamageSource;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.damage.DamageType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class FireSwordPlugin extends JavaPlugin implements Listener {

    // ---- Tweak these (20 damage = 10 hearts) ----
    private static final int BURN_TICKS = 100;                // 5 seconds of burning
    private static final double ARMOR_PASS_THROUGH = 0.75;    // armor only stops 25% of ability damage

    // Fireballs (right-click air): 3 fireballs that explode on impact
    private static final long FIREBALL_COOLDOWN_MS = 3000;
    private static final int FIREBALL_COUNT = 3;              // fireballs per right-click
    private static final double FIREBALL_SPREAD_DEGREES = 8;  // angle between fireballs
    private static final double FIREBALL_DAMAGE = 10.0;       // 5 hearts per fireball
    private static final double FIREBALL_BLAST_RADIUS = 4.5;  // blocks (super explosive)
    private static final float FIREBALL_BLOCK_POWER = 4.0f;   // how much ground it blows up (4 = TNT, higher = bigger crater)
    private static final double FIREBALL_SPACING = 1.4;       // blocks between the 3 fireballs when they launch

    // Fire Shield (sneak + right-click)
    private static final int SHIELD_TICKS = 200;              // lasts 10 seconds
    private static final long SHIELD_COOLDOWN_MS = 20000;     // 20 seconds between shields
    private static final double SHIELD_RADIUS = 3.0;          // blocks
    private static final double SHIELD_DAMAGE = 40.0;         // 20 hearts per hit (5x the old 8.0)
    private static final int SHIELD_INTERVAL_TICKS = 10;      // twice a second = 40 hearts/sec

    // Fire Boom (sneak + hit)
    private static final long BOOM_COOLDOWN_MS = 90000;       // 1 minute 30 seconds
    private static final double BOOM_DAMAGE = 30.0;           // 15 hearts
    private static final double BOOM_RANGE = 30.0;            // blocks
    private static final double BOOM_WIDTH = 1.75;            // how wide the beam is (blocks from its centre line)

    // Sword stats
    private static final double SWORD_ATTACK_DAMAGE = 12.0;     // attack damage shown on the tooltip (before Sharpness)
    private static final double SWORD_ATTACK_SPEED = 1.6;       // same swing speed as a normal sword
    private static final int SWORD_SHARPNESS = 7;               // Sharpness level (adds +4 damage at level 7)

    private static final int CUSTOM_MODEL_ID = 1;             // must match the resource pack

    private boolean inFireballBlast = false;   // true only while our own explosion is being created

    // Built-in resource pack server (the pack lives inside this plugin's jar)
    private HttpServer packServer;
    private ExecutorService packExecutor;
    private byte[] packBytes;
    private byte[] packSha1;
    private boolean warnedNoHost = false;

    private NamespacedKey swordKey;
    private NamespacedKey fireballKey;
    private final Map<UUID, Long> fireballCooldowns = new HashMap<>();
    private final Map<UUID, Long> shieldCooldowns = new HashMap<>();
    private final Map<UUID, Long> boomCooldowns = new HashMap<>();
    private final Map<UUID, BukkitRunnable> shields = new HashMap<>();

    @Override
    public void onEnable() {
        swordKey = new NamespacedKey(this, "fire_sword");
        fireballKey = new NamespacedKey(this, "fire_sword_fireball");
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("FireSword enabled.");
        if (getConfig().getBoolean("resource-pack.enabled", true)
                && getConfig().getString("resource-pack.external-url", "").isBlank()) {
            startPackServer();
        }
    }

    @Override
    public void onDisable() {
        stopPackServer();
        for (BukkitRunnable task : shields.values()) {
            task.cancel();
        }
        shields.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        if (args.length > 0) {
            target = getServer().getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(Component.text("Console must specify a player.", NamedTextColor.RED));
            return true;
        }

        target.getInventory().addItem(createFireSword());
        target.sendMessage(Component.text("You received the Fire Sword!", NamedTextColor.GOLD));
        return true;
    }

    // ---------------------------------------------------------------- item

    private ItemStack createFireSword() {
        ItemStack item = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("Fire Sword", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                line("Ignites enemies on hit", NamedTextColor.RED),
                line("Right-click air: 3 super explosive fireballs", NamedTextColor.YELLOW),
                line("Right-click ground: set it ablaze", NamedTextColor.YELLOW),
                line("Sneak + right-click: Fire Shield", NamedTextColor.GOLD),
                line("Sneak + hit: Fire Boom (1m 30s cooldown)", NamedTextColor.DARK_RED)
        ));
        meta.addEnchant(Enchantment.SHARPNESS, SWORD_SHARPNESS, true);

        // Attack damage 12 (player base is 1, so the modifier adds 11) and normal sword swing speed (base 4 - 2.4 = 1.6)
        meta.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                new NamespacedKey(this, "fire_sword_damage"), SWORD_ATTACK_DAMAGE - 1.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        meta.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                new NamespacedKey(this, "fire_sword_speed"), SWORD_ATTACK_SPEED - 4.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));

        meta.setEnchantmentGlintOverride(true);
        meta.setUnbreakable(true);
        meta.setCustomModelData(CUSTOM_MODEL_ID);   // resource pack swaps in the fire sword model
        meta.getPersistentDataContainer().set(swordKey, PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    private Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private boolean isFireSword(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(swordKey, PersistentDataType.BYTE);
    }

    // ---------------------------------------------------------------- damage helpers

    /** True if the target is wearing at least one piece of armor. */
    private boolean hasArmor(LivingEntity target) {
        EntityEquipment equipment = target.getEquipment();
        if (equipment == null) return false;
        for (ItemStack piece : equipment.getArmorContents()) {
            if (piece != null && !piece.getType().isAir()) return true;
        }
        return false;
    }

    /**
     * Ability damage. It uses magic-type damage, which ignores armor, and then takes 25% off
     * only if the target is wearing armor. So armor never blocks more than 25%.
     */
    private void abilityDamage(LivingEntity target, double amount, Player attacker) {
        abilityDamage(target, amount, attacker, false);
    }

    /** Same as above, but if fullDamage is true armor doesn't reduce it at all. */
    private void abilityDamage(LivingEntity target, double amount, Player attacker, boolean fullDamage) {
        double dealt = (!fullDamage && hasArmor(target)) ? amount * ARMOR_PASS_THROUGH : amount;

        DamageSource.Builder builder = DamageSource.builder(DamageType.MAGIC);
        if (attacker != null) {
            builder.withCausingEntity(attacker).withDirectEntity(attacker);
        }
        target.setNoDamageTicks(0);   // every hit lands in full
        target.damage(dealt, builder.build());
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        if (!player.hasPermission("firesword.use")) return;
        if (!isFireSword(player.getInventory().getItemInMainHand())) return;

        victim.setFireTicks(BURN_TICKS);
        victim.getWorld().spawnParticle(Particle.FLAME, victim.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.02);
        victim.getWorld().playSound(victim.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1f, 1f);
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("firesword.use")) return;
        if (!isFireSword(player.getInventory().getItemInMainHand())) return;

        event.setCancelled(true);

        if (player.isSneaking()) {
            toggleShield(player);
        } else if (action == Action.RIGHT_CLICK_BLOCK) {
            igniteGround(player, event.getClickedBlock(), event.getBlockFace());
        } else {
            shootFireballs(player);
        }
    }

    /** Sneak + swing (hitting air, a block or a mob) fires the Fire Boom. */
    @EventHandler
    public void onSwing(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;
        if (!player.hasPermission("firesword.use")) return;
        if (!isFireSword(player.getInventory().getItemInMainHand())) return;

        fireBoom(player);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        stopShield(event.getPlayer());
    }

    // ---------------------------------------------------------------- resource pack

    /** Serves the pack that is bundled inside the plugin jar, so no GitHub / outside hosting is needed. */
    private void startPackServer() {
        try (InputStream in = getResource("FireSwordPack.zip")) {
            if (in == null) {
                getLogger().warning("FireSwordPack.zip is missing from the plugin jar; no resource pack will be sent.");
                return;
            }
            packBytes = in.readAllBytes();
            packSha1 = MessageDigest.getInstance("SHA-1").digest(packBytes);
        } catch (Exception e) {
            getLogger().warning("Could not read the bundled resource pack: " + e.getMessage());
            return;
        }

        int port = getConfig().getInt("resource-pack.port", 8163);
        try {
            packServer = HttpServer.create(new InetSocketAddress(port), 0);
            packServer.createContext("/FireSwordPack.zip", exchange -> {
                try (exchange) {
                    exchange.getResponseHeaders().add("Content-Type", "application/zip");
                    exchange.sendResponseHeaders(200, packBytes.length);
                    try (OutputStream out = exchange.getResponseBody()) {
                        out.write(packBytes);
                    }
                }
            });
            packExecutor = Executors.newFixedThreadPool(2, r -> {
                Thread t = new Thread(r, "FireSword-PackServer");
                t.setDaemon(true);
                return t;
            });
            packServer.setExecutor(packExecutor);
            packServer.start();
            getLogger().info("Resource pack is being served on port " + port + ". Make sure that port is open/allocated to your server.");
        } catch (IOException | LinkageError e) {
            getLogger().warning("Could not start the resource pack server on port " + port + " (" + e
                    + "). Change resource-pack.port in config.yml to a free port.");
            packServer = null;
        }
    }

    private void stopPackServer() {
        if (packServer != null) {
            packServer.stop(0);
            packServer = null;
        }
        if (packExecutor != null) {
            packExecutor.shutdownNow();
            packExecutor = null;
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!getConfig().getBoolean("resource-pack.enabled", true)) return;

        final String url;
        byte[] hash = null;

        String external = getConfig().getString("resource-pack.external-url", "").trim();
        if (!external.isEmpty()) {
            // Optional: pack hosted somewhere else
            url = external;
            String sha1 = getConfig().getString("resource-pack.external-sha1", "").trim();
            if (!sha1.isEmpty()) {
                try {
                    hash = HexFormat.of().parseHex(sha1);
                    if (hash.length != 20) throw new IllegalArgumentException("wrong length");
                } catch (IllegalArgumentException e) {
                    getLogger().warning("resource-pack.external-sha1 must be 40 hex characters; sending the pack without it.");
                    hash = null;
                }
            }
        } else {
            if (packServer == null) return;
            String host = getConfig().getString("resource-pack.host", "").trim();
            if (host.isEmpty()) {
                // Use the same address the player typed to join the server
                InetSocketAddress joined = event.getPlayer().getVirtualHost();
                if (joined != null) host = joined.getHostString();
            }
            if (host == null || host.isEmpty()) {
                if (!warnedNoHost) {
                    warnedNoHost = true;
                    getLogger().warning("Can't tell which address to send the resource pack from. Set resource-pack.host in config.yml to your server's IP or domain.");
                }
                return;
            }
            if (host.contains(":") && !host.startsWith("[")) host = "[" + host + "]";   // IPv6
            url = "http://" + host + ":" + getConfig().getInt("resource-pack.port", 8163) + "/FireSwordPack.zip";
            hash = packSha1;
        }

        boolean force = getConfig().getBoolean("resource-pack.force", false);
        Component prompt = Component.text(
                getConfig().getString("resource-pack.prompt", "Fire Sword resource pack"), NamedTextColor.GOLD);

        final byte[] finalHash = hash;
        Player player = event.getPlayer();
        // Wait one second so the player is fully loaded in before the download prompt appears
        getServer().getScheduler().runTaskLater(this, () -> {
            if (player.isOnline()) {
                player.setResourcePack(url, finalHash, prompt, force);
            }
        }, 20L);
    }

    // ---------------------------------------------------------------- fireballs

    private void shootFireballs(Player player) {
        long now = System.currentTimeMillis();
        long readyAt = fireballCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < readyAt) {
            player.sendActionBar(Component.text("Fireball cooldown: " + formatTime(readyAt - now), NamedTextColor.RED));
            return;
        }
        fireballCooldowns.put(player.getUniqueId(), now + FIREBALL_COOLDOWN_MS);

        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();

        // Sideways direction, so the fireballs start side by side instead of stacked on one spot
        Vector side = new Vector(-direction.getZ(), 0, direction.getX());
        if (side.lengthSquared() < 1.0E-6) side = new Vector(1, 0, 0);   // looking straight up/down
        side.normalize();

        for (int i = 0; i < FIREBALL_COUNT; i++) {
            double slot = i - (FIREBALL_COUNT - 1) / 2.0;                 // -1, 0, +1 for 3 fireballs
            // Fan the fireballs out evenly around where you're looking
            Vector aim = direction.clone().rotateAroundY(Math.toRadians(slot * FIREBALL_SPREAD_DEGREES));
            Location spawnAt = eye.clone()
                    .add(direction.clone().multiply(1.3))
                    .add(side.clone().multiply(slot * FIREBALL_SPACING));

            player.getWorld().spawn(spawnAt, Fireball.class, fireball -> {
                fireball.setShooter(player);
                fireball.setYield(0f);              // no vanilla explosion; we make our own on impact
                fireball.setIsIncendiary(false);
                fireball.setDirection(aim);
                fireball.setVelocity(aim.clone().multiply(1.2));
                fireball.getPersistentDataContainer().set(fireballKey, PersistentDataType.BYTE, (byte) 1);
            });
        }
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
    }

    /** Each fireball explodes where it lands: huge blast effect, no block damage, hurts everything within the radius. */
    @EventHandler
    public void onFireballHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Fireball fireball)) return;
        if (!fireball.getPersistentDataContainer().has(fireballKey, PersistentDataType.BYTE)) return;

        Player shooter = fireball.getShooter() instanceof Player p ? p : null;

        // Fireballs must never blow up on each other or on the player who fired them
        Entity hitEntity = event.getHitEntity();
        if (hitEntity != null) {
            boolean otherFireball = hitEntity instanceof Fireball other
                    && other.getPersistentDataContainer().has(fireballKey, PersistentDataType.BYTE);
            boolean theShooter = shooter != null && hitEntity.getUniqueId().equals(shooter.getUniqueId());
            if (otherFireball || theShooter) {
                event.setCancelled(true);   // fly straight through
                return;
            }
        }

        event.setCancelled(true);   // skip the vanilla impact so the damage is exactly what we set

        Location loc = fireball.getLocation();
        World world = loc.getWorld();
        fireball.remove();

        // Real explosion that blows holes in the ground. Its own damage is switched off below
        // so the only damage is our exact 5 hearts per fireball.
        inFireballBlast = true;
        try {
            Entity source = shooter;
            world.createExplosion(source, loc, FIREBALL_BLOCK_POWER, false, true);
        } finally {
            inFireballBlast = false;
        }

        // Extra fire effects on top of the vanilla blast
        world.spawnParticle(Particle.FLAME, loc, 200, 2.0, 1.5, 2.0, 0.12);
        world.spawnParticle(Particle.LAVA, loc, 40, 2.0, 1.0, 2.0, 0);
        world.playSound(loc, Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 2f, 1f);

        for (Entity e : world.getNearbyEntities(loc, FIREBALL_BLAST_RADIUS, FIREBALL_BLAST_RADIUS, FIREBALL_BLAST_RADIUS)) {
            if (e instanceof ArmorStand) continue;
            if (!(e instanceof LivingEntity target)) continue;
            if (shooter != null && e.getUniqueId().equals(shooter.getUniqueId())) continue;

            Vector center = target.getBoundingBox().getCenter();
            if (center.distance(loc.toVector()) > FIREBALL_BLAST_RADIUS) continue;

            target.setFireTicks(BURN_TICKS);
            abilityDamage(target, FIREBALL_DAMAGE, shooter, true);   // full 5 hearts, armor doesn't reduce it
        }
    }

    /** While a fireball's explosion is being created, ignore the vanilla explosion damage (we deal our own). */
    @EventHandler(priority = org.bukkit.event.EventPriority.LOWEST)
    public void onExplosionDamage(EntityDamageEvent event) {
        if (!inFireballBlast) return;
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                || cause == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------- ground fire

    private void igniteGround(Player player, Block clicked, BlockFace face) {
        if (clicked == null) return;

        Block spot = clicked.getRelative(face);
        tryIgnite(player, spot);

        // Clicking the top of a block lights a small plus-shaped patch
        if (face == BlockFace.UP) {
            tryIgnite(player, spot.getRelative(BlockFace.NORTH));
            tryIgnite(player, spot.getRelative(BlockFace.SOUTH));
            tryIgnite(player, spot.getRelative(BlockFace.EAST));
            tryIgnite(player, spot.getRelative(BlockFace.WEST));
        }
        player.getWorld().playSound(spot.getLocation(), Sound.ITEM_FLINTANDSTEEL_USE, 1f, 1f);
    }

    private void tryIgnite(Player player, Block block) {
        if (!block.getType().isAir()) return;
        if (!block.getRelative(BlockFace.DOWN).getType().isSolid()) return;

        // Fire the vanilla event first so protection plugins can say no
        BlockIgniteEvent ignite = new BlockIgniteEvent(block, BlockIgniteEvent.IgniteCause.FLINT_AND_STEEL, player);
        getServer().getPluginManager().callEvent(ignite);
        if (ignite.isCancelled()) return;

        block.setType(Material.FIRE);
        block.getWorld().spawnParticle(Particle.FLAME, block.getLocation().add(0.5, 0.3, 0.5), 8, 0.2, 0.1, 0.2, 0.01);
    }

    // ---------------------------------------------------------------- fire boom

    private void fireBoom(Player player) {
        long now = System.currentTimeMillis();
        long readyAt = boomCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < readyAt) {
            player.sendActionBar(Component.text("Fire Boom cooldown: " + formatTime(readyAt - now), NamedTextColor.RED));
            return;
        }
        boomCooldowns.put(player.getUniqueId(), now + BOOM_COOLDOWN_MS);

        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        World world = player.getWorld();

        // The beam stops at the first solid wall
        double range = BOOM_RANGE;
        RayTraceResult wall = world.rayTraceBlocks(eye, dir, BOOM_RANGE, FluidCollisionMode.NEVER, true);
        if (wall != null) {
            range = wall.getHitPosition().distance(eye.toVector());
        }

        world.playSound(eye, Sound.ENTITY_WARDEN_SONIC_BOOM, 3f, 1f);
        world.playSound(eye, Sound.ENTITY_BLAZE_SHOOT, 2f, 0.5f);

        // Beam visuals: a line of flames with sonic-boom rings along it
        int step = 0;
        for (double d = 1.0; d <= range; d += 0.5, step++) {
            Location p = eye.clone().add(dir.clone().multiply(d));
            world.spawnParticle(Particle.FLAME, p, 6, 0.15, 0.15, 0.15, 0.02);
            if (step % 6 == 0) {
                world.spawnParticle(Particle.SONIC_BOOM, p, 1);
            }
        }
        Location end = eye.clone().add(dir.clone().multiply(range));
        world.spawnParticle(Particle.EXPLOSION, end, 1);
        world.playSound(end, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);

        // Hit everything along the beam (it pierces)
        Location mid = eye.clone().add(dir.clone().multiply(range / 2));
        double reach = range / 2 + 2;
        for (Entity e : world.getNearbyEntities(mid, reach, reach, reach)) {
            if (e instanceof ArmorStand) continue;
            if (!(e instanceof LivingEntity target)) continue;
            if (e.getUniqueId().equals(player.getUniqueId())) continue;

            Vector toTarget = target.getBoundingBox().getCenter().subtract(eye.toVector());
            double along = toTarget.dot(dir);
            if (along < 0 || along > range) continue;
            double off = toTarget.clone().subtract(dir.clone().multiply(along)).length();
            if (off > BOOM_WIDTH) continue;

            target.setFireTicks(BURN_TICKS * 2);
            abilityDamage(target, BOOM_DAMAGE, player);
            target.setVelocity(dir.clone().multiply(2.0).setY(0.6));   // blast them back
        }
    }

    // ---------------------------------------------------------------- fire shield

    private void toggleShield(Player player) {
        if (shields.containsKey(player.getUniqueId())) {
            stopShield(player);   // sneak + right-click again ends it early
            return;
        }

        long now = System.currentTimeMillis();
        long readyAt = shieldCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < readyAt) {
            player.sendActionBar(Component.text("Fire Shield cooldown: " + formatTime(readyAt - now), NamedTextColor.RED));
            return;
        }
        shieldCooldowns.put(player.getUniqueId(), now + SHIELD_COOLDOWN_MS);
        startShield(player);
    }

    private void startShield(Player player) {
        // Fire immunity so your own shield (and lava, fire, etc.) can't hurt you while it's up
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, SHIELD_TICKS + 10, 0, false, false));
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1f, 0.6f);
        player.sendActionBar(Component.text("Fire Shield active!", NamedTextColor.GOLD));

        BukkitRunnable task = new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || ticks >= SHIELD_TICKS) {
                    stopShield(player);
                    return;
                }

                Location center = player.getLocation();
                World world = player.getWorld();

                // Ring of flame on the ground around you
                for (int i = 0; i < 16; i++) {
                    double a = angle + i * (Math.PI * 2 / 16);
                    world.spawnParticle(Particle.FLAME,
                            center.getX() + Math.cos(a) * SHIELD_RADIUS,
                            center.getY() + 0.1,
                            center.getZ() + Math.sin(a) * SHIELD_RADIUS,
                            1, 0, 0, 0, 0);
                }

                // Three tall flames orbiting you
                for (int i = 0; i < 3; i++) {
                    double a = -angle * 1.5 + i * (Math.PI * 2 / 3);
                    double height = 0.5 + 0.5 * (1 + Math.sin(angle * 2 + i));
                    world.spawnParticle(Particle.FLAME,
                            center.getX() + Math.cos(a) * (SHIELD_RADIUS - 0.5),
                            center.getY() + height,
                            center.getZ() + Math.sin(a) * (SHIELD_RADIUS - 0.5),
                            3, 0.1, 0.1, 0.1, 0.01);
                }
                angle += 0.3;

                // Burn and hit everything inside the ring, twice a second
                if (ticks % SHIELD_INTERVAL_TICKS == 0) {
                    for (Entity e : player.getNearbyEntities(SHIELD_RADIUS, SHIELD_RADIUS, SHIELD_RADIUS)) {
                        if (e instanceof ArmorStand) continue;
                        if (!(e instanceof LivingEntity target)) continue;
                        if (target.getLocation().distance(center) > SHIELD_RADIUS) continue;
                        target.setFireTicks(BURN_TICKS);
                        abilityDamage(target, SHIELD_DAMAGE, player);
                    }
                }
                ticks++;
            }
        };
        task.runTaskTimer(this, 0L, 1L);
        shields.put(player.getUniqueId(), task);
    }

    private void stopShield(Player player) {
        BukkitRunnable task = shields.remove(player.getUniqueId());
        if (task == null) return;
        task.cancel();
        player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        if (player.isOnline()) {
            player.sendActionBar(Component.text("Fire Shield ended", NamedTextColor.GRAY));
        }
    }

    private static String formatTime(long ms) {
        long total = (ms + 999) / 1000;
        long minutes = total / 60;
        long seconds = total % 60;
        return minutes > 0 ? minutes + "m " + seconds + "s" : seconds + "s";
    }
}
