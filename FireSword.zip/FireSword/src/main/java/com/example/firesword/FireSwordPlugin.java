package com.example.firesword;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class FireSwordPlugin extends JavaPlugin implements Listener {

    private static final int BURN_TICKS = 100;          // 5 seconds
    private static final long FIREBALL_COOLDOWN_MS = 3000;

    private NamespacedKey swordKey;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    @Override
    public void onEnable() {
        swordKey = new NamespacedKey(this, "fire_sword");
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("FireSword enabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        if (args.length > 0) {
            target = getServer().getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(Component.text("Console must specify a player.", NamedTextColor.RED));
            return true;
        }

        target.getInventory().addItem(createFireSword());
        target.sendMessage(Component.text("You received the Fire Sword!", NamedTextColor.GOLD));
        return true;
    }

    private ItemStack createFireSword() {
        ItemStack item = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("Fire Sword", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Ignites enemies on hit", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Right-click: launch a fireball", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        meta.setEnchantmentGlintOverride(true);
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(swordKey, PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    private boolean isFireSword(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(swordKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        if (!player.hasPermission("firesword.use")) return;
        if (!isFireSword(player.getInventory().getItemInMainHand())) return;

        victim.setFireTicks(BURN_TICKS);
        victim.getWorld().spawnParticle(Particle.FLAME, victim.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.02);
        victim.getWorld().playSound(victim.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1f, 1f);
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("firesword.use")) return;
        if (!isFireSword(player.getInventory().getItemInMainHand())) return;

        long now = System.currentTimeMillis();
        long readyAt = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < readyAt) {
            double secondsLeft = (readyAt - now) / 1000.0;
            player.sendActionBar(Component.text(String.format("Cooldown: %.1fs", secondsLeft), NamedTextColor.RED));
            return;
        }
        cooldowns.put(player.getUniqueId(), now + FIREBALL_COOLDOWN_MS);

        Fireball fireball = player.launchProjectile(Fireball.class, player.getLocation().getDirection().multiply(1.2));
        fireball.setYield(0f);          // no block damage
        fireball.setIsIncendiary(false);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
        event.setCancelled(true);
    }
}
